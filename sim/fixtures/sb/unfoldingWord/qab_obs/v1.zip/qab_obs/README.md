# qab_obs

Fixture B Open Bible Stories, a fixture release for the unfoldingWord app sim.
