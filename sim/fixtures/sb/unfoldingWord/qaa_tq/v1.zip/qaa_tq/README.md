# qaa_tq

Fixture Translation Questions, a fixture release for the unfoldingWord app sim.
