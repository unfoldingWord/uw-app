# qaa_obs-twl

Fixture OBS Translation Words Links, a fixture release for the unfoldingWord app sim.
