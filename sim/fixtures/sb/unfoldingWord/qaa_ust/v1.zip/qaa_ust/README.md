# qaa_ust

Fixture Simplified Text, a fixture release for the unfoldingWord app sim.
