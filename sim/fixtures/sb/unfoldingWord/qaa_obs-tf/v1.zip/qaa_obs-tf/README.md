# qaa_obs-tf

Fixture OBS Theological Formation, a fixture release for the unfoldingWord app sim.
