# hbo_uhb

Hebrew Bible (fixture), a fixture release for the unfoldingWord app sim.
