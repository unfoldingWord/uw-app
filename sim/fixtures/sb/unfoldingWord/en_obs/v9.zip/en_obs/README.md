# en_obs

Open Bible Stories (fixture), a fixture release for the unfoldingWord app sim.
