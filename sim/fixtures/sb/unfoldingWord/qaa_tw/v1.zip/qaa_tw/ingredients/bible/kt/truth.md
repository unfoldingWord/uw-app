# truth, true

## Definition:

Truth refers to what agrees with how things really are and with what God has said.

## Translation Suggestions:

* Use the word the language already uses for this idea, if there is one.

(See also: [[rc://*/tw/dict/bible/kt/god]])

## Bible References:

* [3 John 1:1](rc://*/ult/book/3jn/01/01)
* [3 John 1:3](rc://*/ult/book/3jn/01/03)

## Word Data:

* Strong's: G0225
