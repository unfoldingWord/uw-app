# famine

## Definition:

A famine is a time when there is not enough food in a land, often because the rain did not come.

## Translation Suggestions:

* Use the word the language already uses for this idea, if there is one.

(See also: [Naomi](../names/naomi.md))

## Bible References:

* [Ruth 1:1](rc://*/ult/book/rut/01/01)

## Word Data:

* Strong's: H7458
