# Naomi

## Definition:

Naomi was a woman from Bethlehem who moved to Moab with her husband and two sons.

## Translation Suggestions:

* Use the word the language already uses for this idea, if there is one.

(See also: [Ruth](../names/ruth.md), [famine](../other/famine.md))

## Bible References:

* [Ruth 1:2](rc://*/ult/book/rut/01/02)

## Word Data:

* Strong's: H5281
