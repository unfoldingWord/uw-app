# Ruth

## Definition:

Ruth was a woman from Moab who married an Israelite. She stayed with her mother-in-law Naomi after her husband died.

## Translation Suggestions:

* Use the word the language already uses for this idea, if there is one.

(See also: [Naomi](../names/naomi.md), [[rc://*/tw/dict/bible/kt/god]])

## Bible References:

* [Ruth 1:16](rc://*/ult/book/rut/01/16)

## Word Data:

* Strong's: H7327
