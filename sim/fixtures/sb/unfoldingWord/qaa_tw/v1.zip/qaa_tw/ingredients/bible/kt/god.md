# God

## Definition:

In the Bible, the term "God" refers to the eternal being who created the universe out of nothing. God exists as Father, Son and Holy Spirit.

## Translation Suggestions:

* Use the word the language already uses for this idea, if there is one.

(See also: [love](../kt/love.md), [[rc://*/tw/dict/bible/kt/truth]])

## Bible References:

* [Ruth 1:16](rc://*/ult/book/rut/01/16)
* [3 John 1:1](rc://*/ult/book/3jn/01/01)

## Word Data:

* Strong's: H0430, G2316
