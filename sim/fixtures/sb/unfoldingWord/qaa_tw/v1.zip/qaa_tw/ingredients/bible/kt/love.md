# love, beloved

## Definition:

To love another person is to care for that person and do things that will benefit him. The word "beloved" describes someone who is loved.

## Translation Suggestions:

* Use the word the language already uses for this idea, if there is one.

(See also: [God](../kt/god.md), [[rc://*/tw/dict/bible/kt/truth]])

## Bible References:

* [3 John 1:1](rc://*/ult/book/3jn/01/01)

## Word Data:

* Strong's: G0025, G0027
