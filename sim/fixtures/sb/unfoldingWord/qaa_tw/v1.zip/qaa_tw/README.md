# qaa_tw

Fixture Translation Words, a fixture release for the unfoldingWord app sim.
