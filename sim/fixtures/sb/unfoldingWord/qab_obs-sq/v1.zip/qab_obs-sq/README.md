# qab_obs-sq

Fixture B OBS Study Questions, a fixture release for the unfoldingWord app sim.
