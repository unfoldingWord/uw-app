# qaa_obs

Fixture Open Bible Stories, a fixture release for the unfoldingWord app sim.
