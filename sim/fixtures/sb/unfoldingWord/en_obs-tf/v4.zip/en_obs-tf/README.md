# en_obs-tf

OBS Theological Formation (fixture), a fixture release for the unfoldingWord app sim.
