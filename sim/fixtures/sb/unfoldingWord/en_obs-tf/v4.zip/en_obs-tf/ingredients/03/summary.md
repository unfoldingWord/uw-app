# Summary

God saved Noah and his family from the flood that covered the earth.
