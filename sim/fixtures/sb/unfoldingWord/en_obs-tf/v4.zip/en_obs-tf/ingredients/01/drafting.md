# Drafting

Write the story in your language from memory, one frame at a time.
