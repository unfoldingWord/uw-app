# Journal

Write one sentence about what you will remember from this story this week.
