# Discourse

Talk together: what does this story show about how people respond to God?
