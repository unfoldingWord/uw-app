# Key idea

God made everything, and everything he made was good.
