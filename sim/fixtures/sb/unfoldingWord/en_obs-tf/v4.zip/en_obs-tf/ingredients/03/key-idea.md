# Key idea

God judges evil and saves those who trust him.
