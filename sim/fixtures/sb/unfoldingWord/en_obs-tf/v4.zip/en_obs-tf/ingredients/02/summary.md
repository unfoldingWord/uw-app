# Summary

Adam and his wife ate the fruit God had forbidden, and their trust in God was broken.
