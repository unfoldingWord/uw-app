# Key idea

People chose to disobey God, and sin entered the world.
