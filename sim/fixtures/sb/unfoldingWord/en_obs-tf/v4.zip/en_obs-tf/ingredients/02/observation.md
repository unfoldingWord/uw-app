# Observation

Read the story of sin entering the world together twice.

1. What happens in this story?
1. What does God do?
