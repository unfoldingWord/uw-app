# Checking

Read your draft to someone who has not heard the story and ask them to retell it.
