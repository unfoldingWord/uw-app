# Observation

Read the story of the creation together twice.

1. What happens in this story?
1. What does God do?
