# Creedal verse

> In the beginning, God created the heavens and the earth.

[Genesis 1:1](rc://*/ult/book/gen/01/01)
