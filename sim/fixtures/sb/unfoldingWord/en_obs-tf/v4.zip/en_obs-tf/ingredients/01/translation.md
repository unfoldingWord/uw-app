# Translation

Retell the story in your own words, the way you would tell a neighbour.
