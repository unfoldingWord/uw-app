# Summary

God created the world in six days and made people to live with him.
