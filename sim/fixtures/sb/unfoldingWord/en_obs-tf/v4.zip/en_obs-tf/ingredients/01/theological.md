# Theological

What does this story teach about who God is and what he does?
