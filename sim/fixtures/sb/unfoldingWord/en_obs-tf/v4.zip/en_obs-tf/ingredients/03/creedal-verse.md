# Creedal verse

> By faith, Noah, being warned about things not yet seen, prepared a ship for the saving of his house.

[Hebrews 11:7](rc://*/ult/book/heb/11/07)
