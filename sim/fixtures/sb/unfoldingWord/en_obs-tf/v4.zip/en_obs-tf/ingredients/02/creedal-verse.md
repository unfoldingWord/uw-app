# Creedal verse

> Sin entered into the world through one man, and death through sin.

[Romans 5:12](rc://*/ult/book/rom/05/12)
