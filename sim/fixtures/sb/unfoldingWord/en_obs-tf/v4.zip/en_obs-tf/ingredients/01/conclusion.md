# Conclusion

Pray together and thank God for all that he made.
