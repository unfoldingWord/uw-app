# qaa_obs-tn

Fixture OBS Translation Notes, a fixture release for the unfoldingWord app sim.
