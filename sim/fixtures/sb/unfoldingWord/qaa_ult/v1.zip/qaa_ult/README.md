# qaa_ult

Fixture Literal Text, a fixture release for the unfoldingWord app sim.
