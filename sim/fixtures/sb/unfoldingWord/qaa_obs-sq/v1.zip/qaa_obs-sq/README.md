# qaa_obs-sq

Fixture OBS Study Questions, a fixture release for the unfoldingWord app sim.
