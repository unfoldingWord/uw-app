# el-x-koine_ugnt

Greek New Testament (fixture), a fixture release for the unfoldingWord app sim.
