What is a metaphor and how can I translate one?
