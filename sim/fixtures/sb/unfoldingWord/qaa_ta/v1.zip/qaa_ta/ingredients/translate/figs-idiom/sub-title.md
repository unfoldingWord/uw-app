What is an idiom and how can I translate one?
