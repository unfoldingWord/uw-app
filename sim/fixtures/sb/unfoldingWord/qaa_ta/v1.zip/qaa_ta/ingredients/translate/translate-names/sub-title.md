How can I translate names that my readers have never heard?
