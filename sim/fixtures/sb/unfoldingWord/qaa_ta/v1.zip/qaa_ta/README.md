# qaa_ta

Fixture Translation Academy, a fixture release for the unfoldingWord app sim.
