# qaa_tn

Fixture Translation Notes, a fixture release for the unfoldingWord app sim.
