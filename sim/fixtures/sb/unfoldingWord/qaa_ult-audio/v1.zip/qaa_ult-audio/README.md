# qaa_ult-audio

Fixture Literal Text Audio, a fixture release for the unfoldingWord app sim.
