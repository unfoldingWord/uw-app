# qaa_twl

Fixture Translation Words Links, a fixture release for the unfoldingWord app sim.
