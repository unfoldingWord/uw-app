# obs-images

Open Bible Stories Images (fixture), a fixture release for the unfoldingWord app sim.
