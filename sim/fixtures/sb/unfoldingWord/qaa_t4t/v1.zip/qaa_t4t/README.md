# qaa_t4t

Fixture Translation for Translators, a fixture release for the unfoldingWord app sim.
