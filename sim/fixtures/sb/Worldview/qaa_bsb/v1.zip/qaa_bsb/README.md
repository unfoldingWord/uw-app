# qaa_bsb

Fixture Berean Standard Bible, a fixture release for the unfoldingWord app sim.
