# qaa_obs

Fixture Open Bible Stories (Door43 Catalog), a fixture release for the unfoldingWord app sim.
